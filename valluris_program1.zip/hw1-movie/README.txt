To create the executable file, simply use this command:

gcc --std=gnu99 hw1-movie.c -o movies

followed by:

./movies 

